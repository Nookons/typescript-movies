export const firebaseConfig = {
    apiKey: "AIzaSyBL3ozJzfYYQYrcncrdHpy4YGe_y0x93ko",
    authDomain: "rawlplug-management.firebaseapp.com",
    projectId: "rawlplug-management",
    storageBucket: "rawlplug-management.appspot.com",
    messagingSenderId: "751013602102",
    appId: "1:751013602102:web:afb40926f282e4dec94997",
    measurementId: "G-H5MX2Q447M"
};