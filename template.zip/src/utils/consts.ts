
export const HOME_ROUTE = "/"